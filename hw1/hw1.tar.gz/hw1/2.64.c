int any_add_one(unsigned x){
    return (x & 2863311530) != 0;
}
